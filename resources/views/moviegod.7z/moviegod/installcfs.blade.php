<!DOCTYPE html>
<html >
<head>
  @include('moviegod.head')
</head>

<body>
<div class="body">

@include('moviegod.headeradmin')

<div class="form-style-5">
<form  id="form1" method="post"  action="{{ url('/get') }}">
<input type="hidden" name="_token" value="{{ csrf_token() }}">
<h1>
	สร้างการประชุมใหม่
</h1>
<fieldset>
<legend>
	<span class="number">1</span>
	ประเภทการติดตั้ง ระบุชนิดของการติดตั้งของคุณ
หากไม่มีประเภทที่ต้องการให้เลือก 'อื่น ๆ '
</legend>
<legend>
ประเภท (*)
</legend>
<select id="typeconference" name="Data">
	<option value="-" selected="selected">เลือกประเภท*</option>
	<option value="conference" >การประชุม</option>
	<option value="book">หนังสือ</option><option value="teaching">ใช้สำหรับการเรียนการสอน</option>
	<option value="special_issue">วารสารฉบับพิเศษ</option>
	<option value="journal">วารสาร</option>
	<option value="proceedings">การดำเนินงานประชุม</option>
	<option value="application">การประมวลผลคำขอเงินทุนตำแหน่งการแข่งขันหรือข้อเสนออื่นๆ</option>
	<option value="other">อื่นๆ</option>
</select>

<hr>

<legend>
	<span class="number">2</span>
	ชื่อและคำย่อ ใส่ชื่อการประชุมเต็มรูปแบบ
</legend>
<legend>
ชื่อการประชุม  (*):
</legend>
<input type="text" id="Nameconference" value="-" name="Conferencename"  placeholder="Name*">
<legend>
ชื่อย่อ  (*):
</legend>
<input type="text" id="Middlename" value="-" name="Conferencemiddlename" placeholder="Middle Name*">

<hr>

<legend>
	<span class="number">3</span>
	ข้อมูลการประชุม ป้อนหน้าเว็บการประชุม
</legend>
<legend>
หน้าเว็บ:
</legend>
<input type="text" id="webcon" value="" name="Webpage" placeholder="Web page*">
<legend>
ป้อนตำแหน่งการประชุม
</legend>
<br>
<legend>
สถานที่:
</legend>
<input type="text" id="locate" value="" name="Location" placeholder="Location">
<legend>
เมือง (*):
</legend>
<input type="text" id="state" value="" name="State" placeholder="State*">
<legend>
ประเทศ (*):
</legend>
<input type="text" id="country" value="" name="Country" placeholder="Country*">
<hr>

<legend>
	<span class="number">4</span>
	วันที่. ป้อนวันที่สิ้นสุดการประชุม
</legend>
<legend>
	วันที่สิ้นสุด (*):
</legend>
<input type="text" value=""  name="Enddate" id="datepicker" placeholder="End date...">

<label>ป้อนปีการศึกษา</label>
<legend>
	ปี (*):
</legend>
<input type="text" id="year" value="-" name="Years" placeholder="Years* " size="10">
<hr>
<legend><span class="number">5</span>ด้านการวิจัย </legend>
<label>งานวิจัยหลัก:</label>
<select id="maincon" name="primary_area">
<option selected="selected" value="0">เลือกงานวิจัยหลัก*</option>
<option value="6"><font><font>บัญชีและการเงิน</font></font></option>
<option value="8"><font><font>ศิลปะและวรรณคดี</font></font></option>
<option value="11"><font><font>ชีววิทยา</font></font></option>
<option value="5"><font><font>ธุรกิจและการจัดการ</font></font></option>
<option value="3"><font><font>เคมี</font></font></option>
<option value="23"><font><font>วิศวกรรมโยธา</font></font></option>
<option value="1"><font><font>การคำนวณ</font></font></option>
<option value="12"><font><font>วิทยาศาสตร์โลกและสิ่งแวดล้อม</font></font></option>
<option value="15"><font><font>เศรษฐศาสตร์</font></font></option>
<option value="16"><font><font>วิทยาศาสตร์การศึกษา</font></font></option>
<option value="17"><font><font>พลังงาน</font></font></option>
<option value="2"><font><font>วิศวกรรม</font></font></option>
<option value="13"><font><font>พันธุกรรมและชีวสารสนเทศศาสตร์</font></font></option>
<option value="10"><font><font>วิทยาศาสตร์สุขภาพ</font></font></option>
<option value="7"><font><font>ภาษาและภาษาศาสตร์</font></font></option>
<option value="14"><font><font>วัสดุศาสตร์</font></font></option>
<option value="19"><font><font>คณิตศาสตร์และสถิติ</font></font></option>
<option value="24"><font><font>วิศวกรรมเครื่องกล</font></font></option>
<option value="21"><font><font>ปรัชญาและจิตวิทยา</font></font></option>
<option value="4"><font><font>ฟิสิกส์</font></font></option>
<option value="9"><font><font>สังคมศาสตร์</font></font></option>
<option value="22"><font><font>สังคมวิทยาและการเมือง</font></font></option>
<option value="20"><font><font>วิทยาศาสตร์อวกาศ</font></font></option>
<option value="18"><font><font>เทคโนโลยี</font></font></option>
</select>

<label>งานวิจัยรอง:</label>
<select id="subcon" name="secondary_area">
<option selected="selected" value="0">เลือกงานวิจัยรอง*</option>
<option value="6"><font><font>บัญชีและการเงิน</font></font></option>
<option value="8"><font><font>ศิลปะและวรรณคดี</font></font></option>
<option value="11"><font><font>ชีววิทยา</font></font></option>
<option value="5"><font><font>ธุรกิจและการจัดการ</font></font></option>
<option value="3"><font><font>เคมี</font></font></option>
<option value="23"><font><font>วิศวกรรมโยธา</font></font></option>
<option value="1"><font><font>การคำนวณ</font></font></option>
<option value="12"><font><font>วิทยาศาสตร์โลกและสิ่งแวดล้อม</font></font></option>
<option value="15"><font><font>เศรษฐศาสตร์</font></font></option>
<option value="16"><font><font>วิทยาศาสตร์การศึกษา</font></font></option>
<option value="17"><font><font>พลังงาน</font></font></option>
<option value="2"><font><font>วิศวกรรม</font></font></option>
<option value="13"><font><font>พันธุกรรมและชีวสารสนเทศศาสตร์</font></font></option>
<option value="10"><font><font>วิทยาศาสตร์สุขภาพ</font></font></option>
<option value="7"><font><font>ภาษาและภาษาศาสตร์</font></font></option>
<option value="14"><font><font>วัสดุศาสตร์</font></font></option>
<option value="19"><font><font>คณิตศาสตร์และสถิติ</font></font></option>
<option value="24"><font><font>วิศวกรรมเครื่องกล</font></font></option>
<option value="21"><font><font>ปรัชญาและจิตวิทยา</font></font></option>
<option value="4"><font><font>ฟิสิกส์</font></font></option>
<option value="9"><font><font>สังคมศาสตร์</font></font></option>
<option value="22"><font><font>สังคมวิทยาและการเมือง</font></font></option>
<option value="20"><font><font>วิทยาศาสตร์อวกาศ</font></font></option>
<option value="18"><font><font>เทคโนโลยี</font></font></option>
</select>
<label>เสนอแนะด้านการวิจัย:</label>
<textarea id="commentcon" value="-" rows="4" cols="80" name="Area_note" ></textarea>
<hr>
<legend><span class="number">6</span>Organizer.</legend>
<label>ผู้จัด:</label> 
<input id="manager" value="" type="text" name="Organizer" placeholder="name*">
<label>Organizer Web page:</label>
<input id="webpage" value=""  type="text" name="Organizer_Webpage" placeholder="Web page*">
<label>Other:</label> 
<textarea  id="other"  value="-" rows="4" cols="80" name="Other" ></textarea>
</fieldset>
<button type="button" class="ui primary test button" onclick="myFunction()" style="margin-left: 40%">สร้างหัวข้อ</button>

</form>
</div>
<!--Modal Submit -->
<div class="ui small modal" id="modal-test">
  <i class="close icon"></i>
  <div class="header" style="background-color: #80ffaa">
    <h1>#ยืนยันการสร้างหัวข้อ</h1>
  </div>
  <div class="content">
    <div class="left" style="margin-left: 2%">
    	<h2 style="color: black;">หัวข้อ:</h2>
    	<h3 id="c1" style="color: black;"></h3>
    	<br>
    	<h2 style="color: black;">ชื่อการประชุม:</h2>
    	<h3 id="c2" style="color: black;"></h3>
    	<br>
    	<h2 style="color: black;">ชื่อย่อ:</h2>
    	<h3 id="c3" style="color: black;"></h3>
    	<br>
    	<h2 style="color: black;">หน้าเว็บ:</h2>
    	<h3 id="c4" style="color: black;"></h3>
    	<br>
    	<h2 style="color: black;">สถานที่:</h2>
    	<h3 id="c5" style="color: black;"></h3>
    	<br>
    	<h2 style="color: black;">เมือง:</h2>
    	<h3 id="c6" style="color: black;"></h3>
    	<br>
    	<h2 style="color: black;">ประเทศ:</h2>
    	<h3 id="c7" style="color: black;"></h3>
      	<br>
      	<h2 style="color: black;">วันที่สิ้นสุด:</h2>
    	<h3 id="c8" style="color: black;"></h3>
    	<br>
    	<h2 style="color: black;">ปี:</h2>
    	<h3 id="c9" style="color: black;"></h3>
    	<br>
    	<h2 style="color: black;">งานวิจัยหลัก:</h2>
    	<h3 id="c10" style="color: black;"></h3>
    	<br>
    	<h2 style="color: black;">งานวิจัยรอง:</h2>
    	<h3 id="c11" style="color: black;"></h3>
    	<br>
    	<h2 style="color: black;">เสนอแนะด้านการวิจัย:</h2>
    	<h3 id="c12" style="color: black;"></h3>
    	<br>
    	<h2 style="color: black;">ผู้จัด:</h2>
    	<h3 id="c13" style="color: black;"></h3>
    	<br>
    	<h2 style="color: black;">webpage:</h2>
    	<h3 id="c14" style="color: black;"></h3>
    	<br>
    	<h2 style="color: black;">Other:</h2>
    	<h3 id="c15" style="color: black;"></h3>
    	<br>
    </div>
  </div>
  <div class="actions">
      <div class="ui black deny button">
        ยกเลิก
      </div>
      <button type="submit" form="form1" value="Submit" class="ui positive button">
			<a href="/adminhome" ><font color="black">Okay</font></a>
	  </button>
    </div>
</div>
<!--end Modal-->
<script>
function myFunction() {
	var typecon = document.getElementById("typeconference");
    document.getElementById("c1").innerHTML = typecon.value;
    var namecon = document.getElementById("Nameconference");
    document.getElementById("c2").innerHTML = namecon.value;
    var mdnamecon = document.getElementById("Middlename");
    document.getElementById("c3").innerHTML = mdnamecon.value;
    var webcon = document.getElementById("webcon");
    document.getElementById("c4").innerHTML = webcon.value;
    var locate = document.getElementById("locate");
    document.getElementById("c5").innerHTML = locate.value;
    var state = document.getElementById("state");
    document.getElementById("c6").innerHTML = state.value;
    var country = document.getElementById("country");
    document.getElementById("c7").innerHTML = country.value;
    var datepicker = document.getElementById("datepicker");
    document.getElementById("c8").innerHTML = datepicker.value;
    var year = document.getElementById("year");
    document.getElementById("c9").innerHTML = year.value;
    var maincon = document.getElementById("maincon");
    document.getElementById("c10").innerHTML = maincon.value;
    var subcon = document.getElementById("subcon");
    document.getElementById("c11").innerHTML = subcon.value;

    var commentcon = document.getElementById("commentcon");
    document.getElementById("c12").innerHTML = commentcon.value;
    var manager = document.getElementById("manager");
    document.getElementById("c13").innerHTML = manager.value;
    var webpage = document.getElementById("webpage");
    document.getElementById("c14").innerHTML = webpage.value;
    var other = document.getElementById("other");
    document.getElementById("c15").innerHTML = other.value;
    
}
</script>
</div>
</body>
</html>

<!Doctype html>
<html>
  <head>
    <title>ระบบสนับสนุนงานวิจัย</title>
    @include('moviegod.head')
</head>
<body>
<!--  test start 1  -->
@include('moviegod.headeradmin')
<!--  end   -->
<div class="body">
@if(Auth::check())
<?php $Pros = DB::table('producer')->get();?>
<div class="ui four cards" style="margin-top: 5%;overflow-y: hidden;">
        <!--   start 2  -->
          @foreach($Pros as $Teach)

            <div class="ui card" style="width: 300px;height: 408px;margin-left: 2%;margin-right: 2%;">
              <div class="image" style="height: 300px">
                <img src="{{$Teach->image}}">
              </div>
            <div class="content" style="max-height: 70px">
              <a class="header" align = 'center'>{{$Teach->name}}</a>
            </div>
            <div class="black ui button">
              <i class="icon search"></i>
              <a href="/list"><font color="white">view</font></a>
              
            </div>
            </div>
          @endforeach
      <!--  end   -->

</div>
@else

@endif

</div>

      



    <!--footer-->
    
    <!--end footer-->
</body>

</html>
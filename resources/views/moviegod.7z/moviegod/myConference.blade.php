<!Doctype html>
<html>
    <head>
        <title>Conferrencs</title>

        <meta charset="utf-8">
        <link href="{{asset('semantic/semantic.min.css')}}" rel="stylesheet">
        <link href="{{asset('style.css')}}" rel="stylesheet">
        <link rel="shortcut icon" href="{{asset('favicon.ico')}}" />
        <script src="{{asset('jquery-3.1.0.min.js')}}"></script>
        <script src="{{asset('semantic/semantic.min.js')}}"></script>
        <script src="{{asset('moment.js')}}"></script>
        <script src="{{asset('script.js')}}"></script>
        <link href="/images/favicon.ico" rel="icon"/>
        <link rel="StyleSheet" href="/css/cool.css" type="text/css"/>
        <link type="text/css" href="/css/table.css" rel="StyleSheet"/>
        <link rel="StyleSheet" href="/css/menu_cfp.css" type="text/css"/>
        <link href="/css/home_cfp.css" type="text/css" rel="StyleSheet"/>
    </head>


<h1 class="ui menu" style="margin: 0%;margin-left: 4.5%;margin-right: 4.5%">
    <img src="../../images/garland_logo.png">
</h1>
<section id ="mainbox" style="margin-top: 0%;margin-left: 4.5%;margin-right: 4.5%">
<div class="ui menu" style="background-color: #4dffa6">
    <a href="/home" class="item">
      Home
    </a>
    <a class="ui dropdown item">
      Factualy
      <i class="dropdown icon"></i>
      <div class="menu">
        <div class="item">
          <i class="dropdown icon"></i>
          <span class="text">Engineering</span>
          <div class="menu">
            <div onclick="location.href='/list'" class="item">Computer</div>
            <div onclick="location.href='/list'" class="item">Electrical</div>
            <div onclick="location.href='/list'" class="item">Mecanical</div>
          </div>
        </div>
      </div>
    </a>

    <a class="item" href ="/list/archive">
        <i class="icon file text outline"></i>Archive
    </a>
    <a class="item" href ="/list/table">
        <i class="icon table"></i>News
    </a>
    @if(Auth::check())
        <a class="ui dropdown item">
      เก้าอี้นวม
      <i class="dropdown icon"></i>
      <div class="menu">
        <div onclick="location.href='/myaccount'" class="item">บัญชีของฉัน</div>
         <div onclick="location.href='/myConference'" class="item">การประชุมของฉัน</div>
        <div onclick="location.href='/list/install'" class="item">สร้างการประชุมใหม่</div>
        <div class="item">เงื่อนไขการให้บริการ</div>     
      </div>
    </a>
    <a class="item">Wellcome : {{ Auth::user()->name }}</a>
    <a href="{{ route('users.logout') }}" class="ui button">Logout</a>
    @else
        <a class ="ui btn-modal item" href="#">
            <i class="icon rocket"></i><font color="black">Login</font>
        </a>
    @endif
  </div>
   
    
</section>
    <div style="margin-top: 0%;margin-left: 4.5%;margin-right: 4.5%">
      <div class="ui segment">
        <h2>My Conferences</h2>
      </div>
       @if(Auth::check())
      <table class="ui selectable celled table,ui striped table" style="text-align: center;">
        <thead>
          <tr>
              <th>Acronym</th>
              <th>Name</th>
              <th>Location</th>
              <th>Submission<br/>deadline</th>
              <th>Start date</th>
              <th>Topics</th>
              <th></th>
          </tr>
        </thead>
        <tbody>
       
            <tr>
                <td>
                    <a href="">con_acronym</a>
                </td>
                <td>con_name</td>
                <td>con_city</td>
                <td>con_end_date</td>
                <td>Nov 29, 2017</td>
                <td>
                    <a href="">
                        <span class="tag fg_black bg_fuchsia">tourist</span>
                    </a>
                    <a href="">
                        <span class="tag fg_black bg_fuchsia">tourist</span>
                    </a>
                    <a href="">
                        <span class="tag fg_black bg_fuchsia">tourist</span>
                    </a>
                    <a href="">
                        <span class="tag fg_darkred bg_green">gastronomy</span>
                    </a>
                </td>
                <td style="width: auto">
                  <div> 
                      
                          <a href="/aboutConference" class="ui button" style="width:80px;">About</a>
                      
                      
                          <a href="/infoConference" class="ui secondary button" style="width:80px;">Edit</a>
                      
                  </div>
                </td>
            </tr>
            
       
        @endif
        </tbody>
      
          
        
      </table>
    </div>
  </body>
</html>
		<meta charset="utf-8">
		<link href="/semantic/semantic.css" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.13/semantic.min.css"/>
		<link href="/style.css" rel="stylesheet">
		<link rel="shortcut icon" href="/favicon.ico" />
		<link rel="StyleSheet" href="/css/cool.css" type="text/css"/>
        <link type="text/css" href="/css/table.css" rel="StyleSheet"/>
        <link rel="StyleSheet" href="/css/menu_cfp.css" type="text/css"/>
        <link href="/css/home_cfp.css" type="text/css" rel="StyleSheet"/>
        <link rel="stylesheet" href="/code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        </style>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    	<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.13/semantic.min.js"></script>
		<script src="/jquery-3.1.0.min.js"></script>
		<script src="/semantic/semantic.min.js"></script>
		<script src="/moment.js"></script>
		<script src="/script.js"></script>
  		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  		
  		<script>
		  $( function() {
		    $( "#datepicker" ).datepicker({dateFormat: "dd-mm-yy"});
		  } );
		  function getSubmit() {
		        var x = document.getElementById("check");
		        if(x.checked == true){
		          $("#submit").prop('disabled', false);
		        }
  			}
  		</script>
  		
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>My Account</title>
	<link href="{{asset('semantic/semantic.min.css')}}" rel="stylesheet">
    <link href="{{asset('style.css')}}" rel="stylesheet">
    <link rel="shortcut icon" href="{{asset('favicon.ico')}}" />
    <script src="{{asset('jquery-3.1.0.min.js')}}"></script>
    <script src="{{asset('semantic/semantic.min.js')}}"></script>
    <script src="{{asset('moment.js')}}"></script>
    <script src="{{asset('script.js')}}"></script>
    <link href="/images/favicon.ico" rel="icon"/>
    <link rel="StyleSheet" href="/css/cool.css" type="text/css"/>
    <link type="text/css" href="/css/table.css" rel="StyleSheet"/>
    <link rel="StyleSheet" href="/css/menu_cfp.css" type="text/css"/>
    <link href="/css/home_cfp.css" type="text/css" rel="StyleSheet"/>
	<script src="{{asset('semantic/semantic.min.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/1.11.8/semantic.min.js"></script>
	<script>
		function getNameEdit() {
	        $("#txtName").prop('disabled', false);
	        txtName.style.backgroundColor='#fff';
	        $('#btnNameSubmit').show();
			$('#btnNameCancel').show();
			$('#btnNameEdit').hide();
	    }
	    function getSurNameEdit() {
	    	$("#txtSurName").prop('disabled', false);
			txtSurName.style.backgroundColor='#fff';
			$('#btnSurNameSubmit').show();
			$('#btnSurNameCancel').show();
			$('#btnSurNameEdit').hide();
	    }
	    function getOrganizationEdit() {
	    	$("#txtOrganization").prop('disabled', false);
			txtOrganization.style.backgroundColor='#fff';
			$('#btnOrganizationSubmit').show();
			$('#btnOrganizationCancel').show();
			$('#btnOrganizationEdit').hide();
	    }
	    function getWebsiteEdit() {
	    	$("#txtWebsite").prop('disabled', false);
			txtWebsite.style.backgroundColor='#fff';
	    	$('#btnWebsiteSubmit').show();
			$('#btnWebsiteCancel').show();
			$('#btnWebsiteEdit').hide();
	    }
	     function getAddressEdit() {
	     	$("#txtAddress").prop('disabled', false);
			txtAddress.style.backgroundColor='#fff';
	     	$('#btnAddressSubmit').show();
			$('#btnAddressCancel').show();
			$('#btnAddressEdit').hide();
	    }
	    function getNationEdit() {
	    	$("#txtNation").prop('disabled', false);
			txtNation.style.backgroundColor='#fff';
	    	$('#btnNationSubmit').show();
			$('#btnNationCancel').show();
			$('#btnNationEdit').hide();
	    }
	    function getIDEdit() {
	    	$("#txtID").prop('disabled', false);
			txtID.style.backgroundColor='#fff';
	    	$('#btnIDSubmit').show();
			$('#btnIDCancel').show();
			$('#btnIDEdit').hide();
	    }

	    function getSaveNameEdit() {
	        $("#txtName").prop('disabled', true);
			txtName.style.backgroundColor='#d4d4d5';
	        $('#btnNameSubmit').hide();
			$('#btnNameCancel').hide();
			$('#btnNameEdit').show();
	    }
	    function getSaveSurNameEdit() {
	    	$("#txtSurName").prop('disabled', true);
			txtSurName.style.backgroundColor='#d4d4d5';
			$('#btnSurNameSubmit').hide();
			$('#btnSurNameCancel').hide();
			$('#btnSurNameEdit').show();
	    }
	    function getSaveOrganizationEdit() {
	    	$("#txtOrganization").prop('disabled', true);
			txtOrganization.style.backgroundColor='#d4d4d5';
			$('#btnOrganizationSubmit').hide();
			$('#btnOrganizationCancel').hide();
			$('#btnOrganizationEdit').show();
	    }
	    function getSaveWebsiteEdit() {
	    	$("#txtWebsite").prop('disabled', true);
			txtWebsite.style.backgroundColor='#d4d4d5';
	    	$('#btnWebsiteSubmit').hide();
			$('#btnWebsiteCancel').hide();
			$('#btnWebsiteEdit').show();
	    }
	     function getSaveAddressEdit() {
	     	$("#txtAddress").prop('disabled', true);
			txtAddress.style.backgroundColor='#d4d4d5';
	     	$('#btnAddressSubmit').hide();
			$('#btnAddressCancel').hide();
			$('#btnAddressEdit').show();
	    }
	    function getSaveNationEdit() {
	    	$("#txtNation").prop('disabled', true);
			txtNation.style.backgroundColor='#d4d4d5';
	    	$('#btnNationSubmit').hide();
			$('#btnNationCancel').hide();
			$('#btnNationEdit').show();
	    }
	    function getSaveIDEdit() {
	    	$("#txtID").prop('disabled', true);
			txtID.style.backgroundColor='#d4d4d5';
	    	$('#btnIDSubmit').hide();
			$('#btnIDCancel').hide();
			$('#btnIDEdit').show();
	    }

	    function getCancelNameEdit() {
	        $("#txtName").prop('disabled', true);
			txtName.style.backgroundColor='#d4d4d5';
	        $('#btnNameSubmit').hide();
			$('#btnNameCancel').hide();
			$('#btnNameEdit').show();
	    }
	    function getCancelSurNameEdit() {
	    	$("#txtSurName").prop('disabled', true);
			txtSurName.style.backgroundColor='#d4d4d5';
			$('#btnSurNameSubmit').hide();
			$('#btnSurNameCancel').hide();
			$('#btnSurNameEdit').show();
	    }
	    function getCancelOrganizationEdit() {
	    	$("#txtOrganization").prop('disabled', true);
			txtOrganization.style.backgroundColor='#d4d4d5';
			$('#btnOrganizationSubmit').hide();
			$('#btnOrganizationCancel').hide();
			$('#btnOrganizationEdit').show();
	    }
	    function getCancelWebsiteEdit() {
	    	$("#txtWebsite").prop('disabled', true);
			txtWebsite.style.backgroundColor='#d4d4d5';
	    	$('#btnWebsiteSubmit').hide();
			$('#btnWebsiteCancel').hide();
			$('#btnWebsiteEdit').show();
	    }
	     function getCancelAddressEdit() {
	     	$("#txtAddress").prop('disabled', true);
			txtAddress.style.backgroundColor='#d4d4d5';
	     	$('#btnAddressSubmit').hide();
			$('#btnAddressCancel').hide();
			$('#btnAddressEdit').show();
	    }
	    function getCancelNationEdit() {
	    	$("#txtNation").prop('disabled', true);
			txtNation.style.backgroundColor='#d4d4d5';
	    	$('#btnNationSubmit').hide();
			$('#btnNationCancel').hide();
			$('#btnNationEdit').show();
	    }
	    function getCancelIDEdit() {
	    	$("#txtID").prop('disabled', true);
			txtID.style.backgroundColor='#d4d4d5';
	    	$('#btnIDSubmit').hide();
			$('#btnIDCancel').hide();
			$('#btnIDEdit').show();
	    }
	</script>
</head>
<body>
	<h1 class="ui menu" style="margin: 0%;margin-left: 4.5%;margin-right: 4.5%">
    <img src="../../images/garland_logo.png">
</h1>
<section id ="mainbox" style="margin-top: 0%;margin-left: 4.5%;margin-right: 4.5%">
<div class="ui menu" style="background-color: #4dffa6">
    <a href="/home" class="item">
      Home
    </a>
    <a class="ui dropdown item">
      Factualy
      <i class="dropdown icon"></i>
      <div class="menu">
        <div class="item">
          <i class="dropdown icon"></i>
          <span class="text">Engineering</span>
          <div class="menu">
            <div onclick="location.href='/list'" class="item">Computer</div>
            <div onclick="location.href='/list'" class="item">Electrical</div>
            <div onclick="location.href='/list'" class="item">Mecanical</div>
          </div>
        </div>
        <div class="item">Economic</div>
      </div>
    </a>

    <a class="item" href ="/list/archive">
        <i class="icon file text outline"></i>Archive
    </a>
    <a class="item" href ="/list/table">
        <i class="icon table"></i>News
    </a>
    @if(Auth::check())
        <a class="ui dropdown item">
      เก้าอี้นวม
      <i class="dropdown icon"></i>
      <div class="menu">
        <div onclick="location.href='/myaccount'" class="item">บัญชีของฉัน</div>
         <div onclick="location.href='/myConference'" class="item">การประชุมของฉัน</div>
        <div onclick="location.href='/list/install'" class="item">สร้างการประชุมใหม่</div>
        <div class="item">เงื่อนไขการให้บริการ</div>     
      </div>
    </a>
    <a class="item">Wellcome : {{ Auth::user()->name }}</a>
    @else
        <a class ="ui btn-modal item" href="#">
            <i class="icon rocket"></i><font color="black">Login</font>
        </a>
    @endif
  </div>
   
    
</section>
	<br>
	<div class="ui container">
	  	<div class="ui grid">
	  		<form class="four wide column">
	  		</form>
	  		<form class="ui form white segment eight wide column">
	  			<div class="ui center aligned red inverted segment">
				  	<h3>ข้อมูลส่วนตัว</h3>		
		  		</div>
			    <div class="row">
			    	<label><b>ชื่อ</b></label>
			    	<div class="ui two column grid form">
				    	<div class="ten wide column">			    			
				  			<input id="txtName" oldvalue="" value="อภิสิทธิ์" type="text" placeholder="ชื่อ" style="background-color:#d4d4d5">
				  			<script>$("#txtName").prop('disabled', true);</script>
			  			</div>
			  			<div class="six wide column" align="center">			    	
				  			<button id="btnNameEdit" class="ui animated red button" type="button" onclick="getNameEdit()">
					  			<span class="visible content">แก้ไข</span>
					  			<span class="hidden content"><i class="large edit icon"></i></span>
				  			</button>
				  			<button id="btnNameSubmit" class="ui animated red button" type="button" onclick="getSaveNameEdit()">
						  		<span class="visible content">บันทึก</span>
						  		<span class="hidden content"><i class="large checkmark icon"></i></span>
						  	</button>
						  	<script>$('#btnNameSubmit').hide();</script>
						  	<button id="btnNameCancel" class="ui animated red button" type="button" onclick="getCancelNameEdit();">
						  		<span class="visible content">ยกเลิก</span>
						  		<span class="hidden content"><i class="large remove icon"></i></span>
						  	</button>
						  	<script>$('#btnNameCancel').hide();</script>
			  			</div>
			  		</div>
			  	</div>
		  		<br>
		  		<div class="row">
		  			<label><b>นามสกุล</b></label>
		    		<div class="ui two column grid form">
				    	<div class="ten wide column">			    			
				  			<input id="txtSurName" oldvalue="" value="โชติรัตนอมรกิจ" type="text" placeholder="นามสกุล" style="background-color:#d4d4d5">
		    				<script>$("#txtSurName").prop('disabled', true);</script>
			  			</div>
			  			<div class="six wide column" align="center">			    	
				  			<button id="btnSurNameEdit" class="ui animated red button" type="button" onclick="getSurNameEdit()">
					  			<span class="visible content">แก้ไข</span>
					  			<span class="hidden content"><i class="large edit icon"></i></span>
				  			</button>
				  			<button id="btnSurNameSubmit" class="ui red animated button" type="button" onclick="getSaveSurNameEdit()">
						  		<span class="visible content">บันทึก</span>
						  		<span class="hidden content"><i class="large checkmark icon"></i></span>
						  	</button>
						  	<script>$('#btnSurNameSubmit').hide();</script>
						  	<button id="btnSurNameCancel" class="ui animated red button" type="button" onclick="getCancelSurNameEdit();">
						  		<span class="visible content">ยกเลิก</span>
						  		<span class="hidden content"><i class="large remove icon"></i></span>
						  	</button>
						  	<script>$('#btnSurNameCancel').hide();</script>
			  			</div>
			  		</div>
		    	</div>
		    	<br>
		    	<div class="row">
		  			<label><b>องค์กรที่สังกัด</b></label>
		    		<div class="ui two column grid form">
				    	<div class="ten wide column">			    			
				  			<textarea rows="1" id="txtOrganization" oldvalue="" type="text" placeholder="องค์กร" style="background-color:#d4d4d5;height:3em;min-height: 3em;max-height: 4em;">มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตศรีราชา</textarea>
		    				<script>$("#txtOrganization").prop('disabled', true);</script>
			  			</div>
			  			<div class="six wide column" align="center">			    	
				  			<button id="btnOrganizationEdit" class="ui animated red button" type="button" onclick="getOrganizationEdit()">
					  			<span class="visible content">แก้ไข</span>
					  			<span class="hidden content"><i class="large edit icon"></i></span>
				  			</button>
				  			<button id="btnOrganizationSubmit" class="ui red animated button" type="button" onclick="getSaveOrganizationEdit()">
						  		<span class="visible content">บันทึก</span>
						  		<span class="hidden content"><i class="large checkmark icon"></i></span>
						  	</button>
						  	<script>$('#btnOrganizationSubmit').hide();</script>
						  	<button id="btnOrganizationCancel" class="ui animated red button" type="button" onclick="getCancelOrganizationEdit();">
						  		<span class="visible content">ยกเลิก</span>
						  		<span class="hidden content"><i class="large remove icon"></i></span>
						  	</button>
						  	<script>$('#btnOrganizationCancel').hide();</script>
			  			</div>
			  		</div>
		    	</div>
		    	<br>
		    	<div class="row">
		  			<label><b>เว็บไซต์ที่ติดต่อได้</b></label>
		    		<div class="ui two column grid form">
				    	<div class="ten wide column">			    			
				  			<textarea rows="2" id="txtWebsite" oldvalue="" type="text" placeholder="เว็บไซต์" style="background-color:#d4d4d5;height:4em;min-height: 4em;max-height: 8em;">-</textarea>
		    				<script>$("#txtWebsite").prop('disabled', true);</script>
			  			</div>
			  			<div class="six wide column" align="center">			    	
				  			<button id="btnWebsiteEdit" class="ui animated red button" type="button" onclick="getWebsiteEdit()">
					  			<span class="visible content">แก้ไข</span>
					  			<span class="hidden content"><i class="large edit icon"></i></span>
				  			</button>
				  			<button id="btnWebsiteSubmit" class="ui red animated button" type="button" onclick="getSaveWebsiteEdit()">
						  		<span class="visible content">บันทึก</span>
						  		<span class="hidden content"><i class="large checkmark icon"></i></span>
						  	</button>
						  	<script>$('#btnWebsiteSubmit').hide();</script>
						  	<button id="btnWebsiteCancel" class="ui animated red button" type="button" onclick="getCancelWebsiteEdit();">
						  		<span class="visible content">ยกเลิก</span>
						  		<span class="hidden content"><i class="large remove icon"></i></span>
						  	</button>
						  	<script>$('#btnWebsiteCancel').hide();</script>
			  			</div>
			  		</div>
		    	</div>
		    	<br>
		    	<div class="">
		  			<label><b>ที่อยู่ปัจจุบัน</b></label>
		    		<div class="ui two column grid form">
				    	<div class="ten wide column">			    			
				  			<textarea rows="2" id="txtAddress" oldvalue="" type="text" placeholder="ที่อยู่" style="background-color:#d4d4d5;height:6em;min-height: 6em;max-height: 12em;">35/410 แขวงทุ่งครุ เขตทุ่งครุ กรุงเทพ 10140</textarea>
		    				<script>$("#txtAddress").prop('disabled', true);</script>
			  			</div>
			  			<div class="six wide column" align="center">			    	
				  			<button id="btnAddressEdit" class="ui animated red button" type="button" onclick="getAddressEdit()">
					  			<span class="visible content">แก้ไข</span>
					  			<span class="hidden content"><i class="large edit icon"></i></span>
				  			</button>
				  			<button id="btnAddressSubmit" class="ui red animated button" type="button" onclick="getSaveAddressEdit()">
						  		<span class="visible content">บันทึก</span>
						  		<span class="hidden content"><i class="large checkmark icon"></i></span>
						  	</button>
						  	<script>$('#btnAddressSubmit').hide();</script>
						  	<button id="btnAddressCancel" class="ui animated red button" type="button" onclick="getCancelAddressEdit();">
						  		<span class="visible content">ยกเลิก</span>
						  		<span class="hidden content"><i class="large remove icon"></i></span>
						  	</button>
						  	<script>$('#btnAddressCancel').hide();</script>
			  			</div>
			  		</div>
		    	</div>
		    	<br>
		    	<div class="row">
		  			<label><b>สัญชาติ</b></label>
		    		<div class="ui two column grid form">
				    	<div class="ten wide column">			    			
				  			<input id="txtNation"  oldvalue="" value="ไทย" type="text" placeholder="ชื่อประเทศ" style="background-color:#d4d4d5">
		    				<script>$("#txtNation").prop('disabled', true);</script>
			  			</div>
			  			<div class="six wide column" align="center">			    	
				  			<button id="btnNationEdit" class="ui animated red button" type="button" onclick="getNationEdit()">
					  			<span class="visible content">แก้ไข</span>
					  			<span class="hidden content"><i class="large edit icon"></i></span>
				  			</button>
				  			<button id="btnNationSubmit" class="ui red animated button" type="button" onclick="getSaveNationEdit()">
						  		<span class="visible content">บันทึก</span>
						  		<span class="hidden content"><i class="large checkmark icon"></i></span>
						  	</button>
						  	<script>$('#btnNationSubmit').hide();</script>
						  	<button id="btnNationCancel" class="ui animated red button" type="button" onclick="getCancelNationEdit();">
						  		<span class="visible content">ยกเลิก</span>
						  		<span class="hidden content"><i class="large remove icon"></i></span>
						  	</button>
						  	<script>$('#btnNationCancel').hide();</script>
			  			</div>
			  		</div>
		    	</div>
		    	<br>
		    	<div class="row">
		  			<label><b>ชื่อไอดี</b></label>
		    		<div class="ui two column grid form">
				    	<div class="ten wide column">			    			
				  			<input id="txtID" oldvalue="" value="topmyza" type="text" placeholder="ชื่อไอดี" style="background-color:#d4d4d5">
		    				<script>$("#txtID").prop('disabled', true);</script>
			  			</div>
			  			<div class="six wide column" align="center">			    	
				  			<button id="btnIDEdit" class="ui animated red button" type="button" onclick="getIDEdit()">
					  			<span class="visible content">แก้ไข</span>
					  			<span class="hidden content"><i class="large edit icon"></i></span>
				  			</button>
				  			<button id="btnIDSubmit" class="ui red animated button" type="button" onclick="getSaveIDEdit()">
						  		<span class="visible content">บันทึก</span>
						  		<span class="hidden content"><i class="large checkmark icon"></i></span>
						  	</button>
						  	<script>$('#btnIDSubmit').hide();</script>
						  	<button id="btnIDCancel" class="ui animated red button" type="button" onclick="getCancelIDEdit();">
						  		<span class="visible content">ยกเลิก</span>
						  		<span class="hidden content"><i class="large remove icon"></i></span>
						  	</button>
						  	<script>$('#btnIDCancel').hide();</script>
			  			</div>
			  		</div>
		    	</div>
		    	<br>
		    	<div class="row">
		  			<label><b>อีเมลล์</b></label>
		    		<div class="ui two column grid form">
				    	<div class="ten wide column">			    			
				  			<input id="txtEmail" oldvalue="" value="topandapisit@hotmail.com" type="text" placeholder="อีเมลล์" style="background-color:#d4d4d5">
		    				<script>$("#txtEmail").prop('disabled', true);</script>
			  			</div>
			  			
		    	</div>
		    	<br>	
			</form>
			<form class="four wide column">
	  		</form> 
	  	</div>
	</div>
</body>
</html>

<!-- in routes
Route::get('/myaccount',['as'=>'myaccount.myaccount','uses'=>'MovieController@myaccount']); 
-->

<!-- in controller
	 public function myaccount()
    {
    
        return view('myaccount.myaccount');
    }
 -->

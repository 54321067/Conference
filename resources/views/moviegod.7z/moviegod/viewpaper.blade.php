<!Doctype html>
<html>
    <head>
        <title>Paper</title>

        @include('moviegod.head')
    </head>
<body class="body">

@include('moviegod.headeradmin')


    <div class="ui segment" style="margin-top: 0%;margin-left: 4.5%;margin-right: 4.5%">
      <div class="ui blue segment">
      	<div style="display: inline-block;max-width: 49%"><h2>All Papers</h2></div>
        <div style="display: inline-block;margin-left: 60%;max-width: 49%">
        		<button class="ui button google plus">Reviewerที่ยังไม่เลือก</button>
        		<button class="ui button facebook">Paymentที่ยังไม่ได้จ่าย</button>
        </div>
      </div>
      	<div class="ct_tbl">
                                <table class="ct_table" cellpadding="0" cellspacing="0" id="ec:table1">
                                    <thead>
                                        <tr>
                                           <td class="SB_left_td navigation" style="text-align: center;"> Showing&nbsp;<select id="ec:table1:entries" onchange="Tab.tables['ec:table1'].changeEntries()" class="SB_select" name="num_entries">
                                           <option value="10">10</option>
                                           <option value="20">20</option>
                                           <option value="50">50</option>
                                           <option value="100">100</option>
                                           <option value="200">200</option>
                                           <option selected="selected" value="all">all</option>
                                           </td> 
                                        <tr>
                                            <th class="sort_both" onclick="Tab.sortColumn('ec:table1',1)">
                                                <div style="padding-bottom:10pt">รหัสpaper</div>
                                            </th>
                                            <th>ชื่อPaper</th>
                                            <th>Preview Paper</th>
                                            <th class="sort_both" onclick="Tab.sortColumn('ec:table1',4)">
                                                <div style="padding-bottom:10pt">
                                                    Status<br/>Reviewer
                                                </div>
                                            </th>
                                            <th onclick="Tab.sortColumn('ec:table1',5)" class="sort_both">
                                                <div style="padding-bottom:10pt">StatusPayment</div>
                                            </th>
                                            <th>Topic</th> 
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="green" id="row8">
                                            <td>
                                                <a href="/viewpaper">0136157</a>
                                            </td>
                                            <td>A.I.Pacman 2017</td>
                                            <td><a href="">Pacman.pdf</a></td>
                                            <td class="center">
                                                <span class="cfp_date">
                                                	<i class="icon checkmark">
                                                	</i>	
                                                </span>
                                            </td>
                                            <td class="center">
                                                <span class="cfp_date">
                                                	<i class="icon remove">
                                                	</i>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="/cfp/topic.cgi?tid=84867;a=15952254">
                                                    <span class="tag fg_black bg_seagreenlight">technology</span>
                                                </a>
                                                <a href="/cfp/topic.cgi?a=15952254;tid=9155">
                                                    <span class="tag fg_black bg_gray1">science</span>
                                                </a>
                                                <a href="/cfp/topic.cgi?tid=69978;a=15952254">
                                                    <span class="tag fg_black bg_fuchsia">tourist</span>
                                                </a>
                                                <a href="/cfp/topic.cgi?tid=1094397;a=15952254">
                                                    <span class="tag fg_darkred bg_green">gastronomy</span>
                                                </a>
                                            </td>
                                        </tr>
                                        <tr id="row15" class="green">
                                            <td>
                                                <a href="/viewpaper">0315461</a>
                                            </td>
                                            <td>Newtron Hydrogen 2017</td>
                                            <td><a href="">atom.pdf</a></td>
                                            <td class="center">
                                                <span class="cfp_date">
                                                	<i class="icon checkmark">
                                                	</i>
                                                </span>
                                            </td>
                                            <td class="center">
                                                <span class="cfp_date">
                                                	<i class="icon remove">
                                                	</i>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="/cfp/topic.cgi?a=15952254;tid=154661">
                                                    <span class="tag fg_bluelight bg_aqua">cyber physical systems</span>
                                                </a>
                                                <a href="/cfp/topic.cgi?tid=200145;a=15952254">
                                                    <span class="tag fg_blue bg_fuchsia">internet of things</span>
                                                </a>
                                                <a href="/cfp/topic.cgi?a=15952254;tid=2942">
                                                    <span class="tag fg_fuchsia bg_seagreenlight">real time systems</span>
                                                </a>
                                                <a href="/cfp/topic.cgi?a=15952254;tid=840">
                                                    <span class="tag fg_black bg_seagreenlight">embedded systems</span>
                                                </a>
                                            </td>
                                        </tr>
                                        
                                        
                                            
                                    </tbody>
                                </table>
                            </div>
                        </div>
	
    </div>
    </body>
</html>

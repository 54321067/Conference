<!Doctype html>
<html>
    <head>
        <title>AdminConferrencs</title>
        @include('moviegod.head')
    </head>

<body>
<div class="body">
@include('moviegod.headeradmin')
<?php $forms = DB::table('form')->get();?>
@if(Auth::check())
<div class="subcontent">
    <h2 class="ui segment">All Conference</h2>
    
    <div class="ct_tbl">
        <table class="ct_table" cellpadding="0" cellspacing="0" id="ec:table1">
            <thead>
                <tr>
                   <td class="SB_left_td navigation" style="text-align: center;"> Showing&nbsp;<select id="selectdata" onchange="Tab.tables['ec:table1'].changeEntries()" class="SB_select" name="num_entries">
                   <option value="10">10</option>
                   <option value="20">20</option>
                   <option value="50">50</option>
                   <option value="100">100</option>
                   <option value="200">200</option>
                   <option selected="selected" value="all">all</option>
                   </select>
                   </td>
                </tr> 
                <tr>
                    <th class="sort_both" onclick="Tab.sortColumn('ec:table1',1)">
                        <div style="padding-bottom:10pt">ชื่อย่อ</div>
                    </th>
                    <th>Name</th>
                    <th>Location</th>
                    <th class="sort_both" onclick="Tab.sortColumn('ec:table1',4)">
                        <div style="padding-bottom:10pt">
                            Submission<br/>deadline
                        </div>
                    </th>
                    <th onclick="Tab.sortColumn('ec:table1',5)" class="sort_both">
                        <div style="padding-bottom:10pt">Start date</div>
                    </th>
                    <th>Topics</th>
                    
                </tr>
            </thead>
            <tbody>
                
                
                @foreach($forms as $form)
                <tr class="green" id="row8">
                    <td>
                        <a href="/viewpaper">{{$form->Mdname}}</a>
                    </td>
                    <td>{{$form->Name}}</td>
                    <td>{{$form->locate}}</td>
                    <td class="center">
                        <span class="cfp_date">{{$form->Enddate}}</span>
                    </td>
                    <td class="center">
                        <span class="cfp_date">{{$form->Years}}</span>
                    </td>
                    <td>
                        <a href="/cfp/topic.cgi?tid=84867;a=15952254">
                            <span class="tag fg_black bg_seagreenlight">technology</span>
                        </a>
                        <a href="/cfp/topic.cgi?a=15952254;tid=9155">
                            <span class="tag fg_black bg_gray1">science</span>
                        </a>
                        <a href="/cfp/topic.cgi?tid=69978;a=15952254">
                            <span class="tag fg_black bg_fuchsia">tourist</span>
                        </a>
                        <a href="/cfp/topic.cgi?tid=1094397;a=15952254">
                            <span class="tag fg_darkred bg_green">gastronomy</span>
                        </a>
                    </td>
                    
                </tr>
                @endforeach
               





                
                
                    
            </tbody>
        </table>
    </div>
</div>
@else



@endif


</div>
</body>
</html>

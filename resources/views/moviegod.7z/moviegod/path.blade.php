<!Doctype html>
<html>
	<head>
		<title>ระบบผู้ดูแลConference</title>

		 @include('moviegod.head')
		
	</head>
<body>
<div class="body">


@include('moviegod.headeradmin')



<br>
</div>
</body>
</html>
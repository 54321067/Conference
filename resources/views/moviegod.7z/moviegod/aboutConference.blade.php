<!Doctype html>
<html>
    <head>
        <title>Conferrencs</title>

        @include('moviegod.head')
    </head>

<body class="body">
@include('moviegod.headeradmin')

 <div class="ui segment" style="margin-top: 0%;margin-left: 4.5%;margin-right:4.5%;">
      <div class="ui blue segment">
        <h2>Name Conferences</h2>
      </div>
      <div class="subcontent">
			<div style="clear:right" id="cfp">
				<div class="ui segment">
					<span class="separ">&bull;</span>
					<a href="#CFP:1">Presentation</a>
					<span class="separ">&bull;</span>
					<a href="#CFP:2">List of topics</a>
					<span class="separ">&bull;</span>
					<a href="#CFP:3">Committees</a>
					<span class="separ">&bull;</span>
					<a href="#CFP:4">Invited Speakers</a>
					<span class="separ">&bull;</span>
					<a href="#CFP:5">Communication</a>
					<span class="separ">&bull;</span>
					<a href="#CFP:6">Call for papers</a>
					<span class="separ">&bull;</span>
					<a href="#CFP:7">Inscriptions</a>
					<span class="separ">&bull;</span>
					<a href="#CFP:8">Contact</a>
					<span class="separ">&bull;</span>
					<a href="#CFP:9">Address</a>
				</div>
				<table>
					<tr>
						<td style="width: 842.55px">
							<div class="ui attached segment">
								<h>
								  TURGATEC 2017: I Congreso sobre Turismo, Gastronomía y Nuevas Tecnologías - TURGATEC 2017
								</h>
								
							</div>
							<div class="ui attached segment" style="margin-right: 4%">
							  	<p>Loja, Ecuador, November 29-December 2, 2017</p>
							</div>
						</td>
					</tr>
				</table>
				<table class="ui selectable celled table,ui striped table">
					<tr>
						<td>Conference website</td>
						<td>
							<a target="_blank" href="https://www.utpl.edu.ec/turgatec/">https://www.utpl.edu.ec/turgatec/</a>
						</td>
					</tr>
					<tr>
						<td>Submission link</td>
						<td>
							<a target="_blank" href="https://easychair.org/conferences/?conf=turgatec2017">https://easychair.org/conferences/?conf=turgatec2017</a>
						</td>
					</tr>
					<tr>
						<td>Abstract registration deadline</td>
						<td>September 29, 2017</td>
					</tr>
					<tr>
						<td>Submission deadline</td>
						<td>November 15, 2017</td>
					</tr>
				</table>
				<div class="topics">Topics: 
					<a href="">
					<span class="tag fg_black bg_seagreenlight">technology</span></a> 
					<a href="">
					<span class="tag fg_black bg_gray1">science</span></a> 
					<a href="">
					<span class="tag fg_black bg_fuchsia">tourist</span></a> 
					<a href="">
					<span class="tag fg_darkred bg_green">gastronomy</span></a>
				</div>
					<h2><a name="CFP:1">Presentation</a></h2>
					<hr>
				<div class="ui ignored message">
					<p style="text-align:justify">La Universidad Técnica Particular de Loja, el área Administrativa a través del Departamento de Ciencias Empresariales, la Sección de Hotelería y Turismo, convocan a la comunidad académica, emprendimientos y empresarial al I Congreso sobre Turismo, Gastronomía y Nuevas Tecnologías - Turgatec 2017, que tendrá lugar el 29, 30 de noviembre y 1 de diciembre de 2017 en Loja, Ecuador. El Turgatec es un evento científico-técnico-empresarial, destinado a la presentación y discusión de conocimientos, experiencias e innovación en las áreas de Turismo, Patrimonio y Cultura Turística, Industria Creativa, Gastronomía, Emprendimientos y Nuevas Tecnologías.</p>
				</div>
				
    		</div>
    	</div>
    </div>
</body>
</html>
